"""Version unique affichée et enregistrée par VISU PTBG."""

VERSION_VISU = "0.9.0"
